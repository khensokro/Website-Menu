<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body>

    <?php include_once('menu.php'); ?>
    <h1> រៀនអាយធីវេទនាណាស់បាច់ខំរៀនទេកុំអោយវេទនាទៀត។ </h1>
</body>
</html>