<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="CSS/style.css">
</head>
<body style="background-color: #f0f0f0;"> <!-- Replace #f0f0f0 with the desired color code -->
    <?php include_once('menu.php'); ?>
    <h1>សួស្ដី</h1>
</body>
</html>
