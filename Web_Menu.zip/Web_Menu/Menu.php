
<a href="index.php">Home</a>
<a href="contact.php">contat</a>
<a href="about.php">about</a>
<a href="Slid.php">Slid</a>
